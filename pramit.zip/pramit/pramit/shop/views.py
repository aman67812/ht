from django.shortcuts import render

from .models import Products,Contact,Order,Users
from math import ceil
import random
# Create your views here.
def index(request):
    login = 'true'
    aprod = []
    catprod = Products.objects.values('categoty', 'id')
    cats = {item['categoty'] for item in catprod}
    for cat in cats:
        prod = Products.objects.filter(categoty=cat)
        n = len(prod)
        nos = n // 4 + ceil((n / 4) - (n // 4))
        aprod.append([prod, range(1, nos), nos])
    params = {'allprod': aprod}
    return render(request,"shop/index.html",params)

def contact(request):
   if request.method=="POST":
      name=request.POST.get('name')
      email = request.POST.get('email')
      mobile = request.POST.get('mob')
      a=int(len(mobile))
      if a<10 or a>10:
         print(len(mobile))
         return render(request, "shop/contact.html",{"error":"Invalid mobile Number"} )

      msg = request.POST.get('con')
      con=Contact(Name=name,Email=email,Mobile=mobile,Message=msg)
      con.save()
      return render(request, "shop/contact.html", {'error': 'Succesfully send'})
   else:
     return render(request,"shop/contact.html",{'error':'none'})
def tracking(request):
    return render(request,"shop/tracking.html")
def cart(request):
    return render(request,"shop/shop-cart.html")
def product(request,id):
   myid=id
   products=Products.objects.filter(id=myid)
   return render(request,"shop/product-details.html",{'product':products[0]})
def shop(request):
    login = 'true'
    aprod = []
    catprod = Products.objects.values('categoty', 'id')
    cats = {item['categoty'] for item in catprod}
    for cat in cats:
        prod = Products.objects.filter(categoty=cat)
        n = len(prod)
        nos = n // 4 + ceil((n / 4) - (n // 4))
        aprod.append([prod, range(1, nos), nos])
    params = {'allprod': aprod}
    return render(request,"shop/shop.html",params)
thanks=1
def orderNow(request):
   if request.method == 'POST':
      t=0
      fname=request.POST.get('fname')
      lname = request.POST.get('lname')
      name=fname+lname
      email = request.POST.get('email')
      mobile = request.POST.get('mobile')
      address = request.POST.get('address')
      city = request.POST.get('city')
      state = request.POST.get('state')
      zip = request.POST.get('zip')
      items=request.POST.get('items')
      price = request.POST.get('price')
      print(fname,lname,email,mobile,address,city,state,zip,items,price )
      if items!='':
         order=Order(Name=name,Email=email,Mobile=mobile,Address=address,City=city,State=state,Zip=zip,Orders=items,price=price)
         order.save()
         id=order.orderid
         number=random.randint(1000,100000)
         idnew='IKART'+str(number)+str(id)
         saveid=Order.objects.get(pk=id)
         saveid.Track_Id=idnew
         saveid.save()
         trackorder=TrackOrder(Order_id=idnew,Email=email,order_Description='Your Order Has Been Placed')
         trackorder.save()
         t=1
         return render(request, "shop/confirmation.html",{'id':idnew} )
         request.method ='GET'
      if items!='' and thanks % 2 != 0:
         return render(request,"shop/index.html")
      else:
         return render(request,"shop/index.html")
   else:
      return render(request, "shop/index.html")
